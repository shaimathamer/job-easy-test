import requests 

def get_data_from_api(api_url):
    try:
        response = requests.get(api_url)
        return response.json() if response.ok else None
    except Exception as e:
        print(f"An error occurred: {e}")
        return None

def main():
    api_url = 'http://127.0.0.1:5000/datos'
    data = get_data_from_api(api_url)
    print("Data retrieved successfully:", data) if data else print("Failed to retrieve data from the API.")

if __name__ == "__main__":
    main()


